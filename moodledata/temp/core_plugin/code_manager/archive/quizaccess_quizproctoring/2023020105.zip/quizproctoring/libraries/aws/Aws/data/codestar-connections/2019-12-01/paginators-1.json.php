<?php
// This file was auto-generated from sdk-root/src/data/codestar-connections/2019-12-01/paginators-1.json
return [ 'pagination' => [ 'ListConnections' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListHosts' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
