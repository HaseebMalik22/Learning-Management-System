//Theme info
document.getElementById("theme-info").innerHTML = "Moodle Theme Almondb - Writer Themes Almond";
